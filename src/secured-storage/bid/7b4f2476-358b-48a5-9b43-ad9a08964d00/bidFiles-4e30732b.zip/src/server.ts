import express, { Request, Response } from "express";
import bodyParser from "body-parser";
import cors from "cors";
import dotenv from "dotenv";
import { MailerService } from "./emailSender"; // Import the MailerService

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors()); // Add this line to enable CORS
app.use(bodyParser.json());
app.use(express.static("src/public"));

const mailer = new MailerService(); // Create an instance of MailerService

// GET Endpoint
app.get("/", (req: Request, res: Response) => {
  res.status(200).json({ message: "Server is running!" });
});

// POST Endpoint
app.post(
  "/api/send-email",
  async (req: Request, res: Response): Promise<void> => {
    const { toFirst, toSecond, subject, text } = req.body;

    if (!toFirst || !toSecond || !subject || !text) {
      res.status(400).json({
        error: "All fields (toFirst, toSecond, subject, text) are required.",
      });
      return;
    }

    try {
      // Call sendEmail from MailerService
      await mailer.sendEmail(toFirst, toSecond, subject, text);
      res.status(200).json({ message: "Email sent successfully!" });
    } catch (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ error: "Failed to send email." });
    }
  }
);

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
