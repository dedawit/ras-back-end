import * as nodemailer from "nodemailer";

export class MailerService {
  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: "connecthopia.com",
      port: 465,
      secure: true,
      auth: {
        user: process.env.email, // Ensure email is set in environment variables
        pass: process.env.password, // Ensure password is set in environment variables
      },
      logger: true,
      debug: true,
    });
  }

  async sendEmail(
    toFirst: string,
    toSecond: string,
    subject: string,
    text: string
  ): Promise<void> {
    try {
      const mailOptions: nodemailer.SendMailOptions = {
        from: `"Connecthopia" <${process.env.email}>`, // Sender email
        to: `${toFirst}, ${toSecond}`, // Both email addresses as comma-separated
        subject,
        text,
      };

      const response = await this.transporter.sendMail(mailOptions);
      console.log(
        `Email sent successfully to ${toFirst} and ${toSecond}: ${response.messageId}`
      );
    } catch (error: any) {
      console.error(
        `Failed to send email to ${toFirst} and ${toSecond}:`,
        error.message
      );
      throw new Error(`Email sending failed. Reason: ${error.message}`);
    }
  }
}
